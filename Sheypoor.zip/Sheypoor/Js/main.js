// Start NavBar Section
    var Myaccount_List = document.querySelector(".Myaccount-List");
    var Myaccount = document.querySelector(".Myaccount");
    var Support = document.querySelector(".Support");
    var Support_List = document.querySelector(".Support-List");
    
    Support.addEventListener("click",()=>{
        Support_List.classList.toggle("d-block");
    });

    Myaccount.addEventListener("click",()=>{
        Myaccount_List.classList.toggle("d-block");
    });
// End NavBar Section
